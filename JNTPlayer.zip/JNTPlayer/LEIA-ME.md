# JNT Player — transformar em app (APK) em 5 passos

Você não precisa instalar nada nem usar terminal. O GitHub (gratuito) compila o app
para você em cerca de 5 minutos. Escolha UM dos dois caminhos.

## Caminho A — pelo computador (arrastando a pasta)
1. Crie uma conta em https://github.com e clique em **New repository**.
   Nome: `jnt-player`, marque **Private**, clique em **Create repository**.
2. Descompacte este ZIP no computador.
3. Na página do repositório, clique em **uploading an existing file** e arraste
   TODO o conteúdo da pasta `JNTPlayer` (inclusive a pasta oculta `.github`).
   - Não vê a `.github`? Ative "mostrar arquivos ocultos"
     (Mac: Cmd+Shift+.  |  Windows: Exibir > Itens ocultos).
4. Clique em **Commit changes**.

## Caminho B — enviando só o ZIP (funciona até pelo celular)
1. Crie a conta e o repositório (passo 1 acima).
2. Na página do repositório: **Add file > Create new file**.
   No nome do arquivo digite exatamente: `.github/workflows/build-apk.yml`
   Cole dentro o conteúdo do arquivo `build-apk.yml` (vai junto com este ZIP) e clique em **Commit changes**.
3. Depois: **Add file > Upload files**, envie o ZIP `JNTPlayer.zip` SEM descompactar
   e clique em **Commit changes**.

## Depois (nos dois caminhos)
5. Abra a aba **Actions**. A execução "Gerar APK do JNT Player" roda sozinha
   (a primeira do Caminho B termina rápido sem fazer nada; é normal).
   Se não rodar: clique no workflow > **Run workflow**.
6. Quando ficar com o ✔ verde, abra a execução e baixe **JNT-Player-APK**
   (seção Artifacts). Descompacte e envie o `app-release.apk` para o celular
   (WhatsApp, e-mail, Drive ou cabo).
7. No celular, toque no APK. Se pedir, permita "instalar apps desconhecidos"
   para o app que você usou para abrir o arquivo.
8. Abra o JNT Player e toque em "Permitir acesso às músicas".
   Sua biblioteca aparece sozinha.

## Alternativa: Android Studio (no computador)
Abra a pasta `JNTPlayer`, aguarde o "Gradle sync" e use
Build > Build Bundle(s) / APK(s) > Build APK(s).

## Observações
- Ícone do app: a arte enviada (fones + J). O original está em `design/icone-original.png`.
- O APK é assinado com a chave de debug: serve para uso pessoal.
- No Android 13+ o app pede também a permissão de notificações (para os controles
  na barra). Ela é opcional.
- Se o build falhar: em Actions abra a execução com ❌ e me envie o texto do erro.
