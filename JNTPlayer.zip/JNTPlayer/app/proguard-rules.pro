# regras R8 (minify desativado por padrão)
