package com.jnt.player.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import com.jnt.player.data.Song
import com.jnt.player.playback.PlayerState
import com.jnt.player.ui.theme.JntColors

@Composable
fun PlayerScreen(
    song: Song,
    state: PlayerState,
    isFavorite: Boolean,
    vm: MainViewModel,
    onClose: () -> Unit,
    onAddToPlaylist: () -> Unit
) {
    val coverScale by animateFloatAsState(
        targetValue = if (state.isPlaying) 1f else 0.92f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessLow),
        label = "coverScale"
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1E1E1E), JntColors.Bg, JntColors.Bg)))
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 28.dp)
                .pointerInput(Unit) {
                    var total = 0f
                    detectVerticalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = { if (total > 180f) onClose() },
                        onVerticalDrag = { _, delta -> total += delta }
                    )
                }
        ) {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Fechar player", modifier = Modifier.size(30.dp))
                }
                Text(
                    "TOCANDO AGORA",
                    color = JntColors.TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 2.sp,
                    modifier = Modifier.weight(1f),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                Spacer(Modifier.size(48.dp))
            }

            Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 16.dp), contentAlignment = Alignment.Center) {
                AnimatedContent(
                    targetState = song,
                    transitionSpec = {
                        (fadeIn(tween(350)) + scaleIn(tween(350), initialScale = 0.94f)) togetherWith fadeOut(tween(200))
                    },
                    label = "playerCover"
                ) { s ->
                    CoverImage(
                        s,
                        Modifier
                            .aspectRatio(1f)
                            .graphicsLayer {
                                scaleX = coverScale
                                scaleY = coverScale
                            }
                            .shadow(24.dp, androidx.compose.foundation.shape.RoundedCornerShape(24.dp)),
                        corner = 24.dp,
                        px = 900
                    )
                }
            }

            AnimatedContent(
                targetState = song,
                transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(150)) },
                label = "playerTitle"
            ) { s ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            s.title,
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            s.artist,
                            color = JntColors.TextSecondary,
                            fontSize = 16.sp,
                            maxLines = 1,
                            modifier = Modifier.basicMarquee()
                        )
                    }
                    IconButton(onClick = onAddToPlaylist) {
                        Icon(Icons.Rounded.PlaylistAdd, contentDescription = "Adicionar à playlist", modifier = Modifier.size(28.dp))
                    }
                    IconButton(onClick = { vm.toggleFavorite(s) }) {
                        Icon(
                            if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                            contentDescription = if (isFavorite) "Remover dos favoritos" else "Favoritar",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            SeekBar(vm, state.durationMs.takeIf { it > 0 } ?: song.durationMs)
            Spacer(Modifier.height(8.dp))

            Row(
                Modifier.fillMaxWidth().padding(bottom = 28.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                ToggleIcon(Icons.Rounded.Shuffle, "Aleatório", state.shuffle) { vm.toggleShuffle() }
                IconButton(onClick = { vm.previous() }, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Rounded.SkipPrevious, contentDescription = "Anterior", modifier = Modifier.size(38.dp))
                }
                Box(
                    Modifier
                        .size(76.dp)
                        .bounceClick { vm.toggle() }
                        .clip(CircleShape)
                        .background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    AnimatedContent(targetState = state.isPlaying, label = "playPause") { playing ->
                        Icon(
                            if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = if (playing) "Pausar" else "Reproduzir",
                            tint = Color.Black,
                            modifier = Modifier.size(42.dp)
                        )
                    }
                }
                IconButton(onClick = { vm.next() }, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Rounded.SkipNext, contentDescription = "Próxima", modifier = Modifier.size(38.dp))
                }
                ToggleIcon(
                    if (state.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    "Repetir",
                    state.repeat != Player.REPEAT_MODE_OFF
                ) { vm.cycleRepeat() }
            }
        }
    }
}

@Composable
private fun SeekBar(vm: MainViewModel, duration: Long) {
    val position by vm.position.collectAsStateWithLifecycle()
    var drag by remember { mutableStateOf<Float?>(null) }
    val max = duration.coerceAtLeast(1L).toFloat()
    val value = (drag ?: position.toFloat()).coerceIn(0f, max)

    Column {
        Slider(
            value = value,
            onValueChange = { drag = it },
            onValueChangeFinished = {
                drag?.let { vm.seekTo(it.toLong()) }
                drag = null
            },
            valueRange = 0f..max,
            modifier = Modifier.fillMaxWidth(),
            thumb = { Box(Modifier.size(12.dp).background(Color.White, CircleShape)) },
            track = { sliderState ->
                val fraction = (sliderState.value / max).coerceIn(0f, 1f)
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF2E2E2E))
                ) {
                    Box(Modifier.fillMaxWidth(fraction).fillMaxHeight().background(Color.White))
                }
            }
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(value.toLong()), color = JntColors.TextSecondary, fontSize = 12.sp)
            Text(formatTime(duration), color = JntColors.TextSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ToggleIcon(icon: ImageVector, description: String, active: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = onClick) {
            Icon(
                icon,
                contentDescription = description,
                tint = if (active) Color.White else JntColors.TextTertiary,
                modifier = Modifier.size(26.dp)
            )
        }
        Box(
            Modifier
                .size(4.dp)
                .background(if (active) Color.White else Color.Transparent, CircleShape)
        )
    }
}
