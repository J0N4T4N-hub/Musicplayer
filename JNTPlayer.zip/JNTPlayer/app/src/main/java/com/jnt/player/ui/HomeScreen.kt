package com.jnt.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jnt.player.ui.theme.JntColors
import java.util.Calendar

private fun greeting(): String {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        hour < 12 -> "Bom dia"
        hour < 18 -> "Boa tarde"
        else -> "Boa noite"
    }
}

@Composable
fun HomeScreen(vm: MainViewModel, nav: Nav, ctx: ListCtx) {
    val songs by vm.recentlyAdded.collectAsStateWithLifecycle()
    val recents by vm.recents.collectAsStateWithLifecycle()
    val albums by vm.albums.collectAsStateWithLifecycle()
    val artists by vm.artists.collectAsStateWithLifecycle()
    val favorites by vm.favoriteSongs.collectAsStateWithLifecycle()

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Column(Modifier.statusBarsPadding().padding(horizontal = 20.dp, vertical = 16.dp)) {
                JntLogo()
                Spacer(Modifier.height(14.dp))
                Text(greeting(), color = JntColors.TextSecondary, fontSize = 15.sp)
                Text(
                    plural(songs.size, "música na sua biblioteca", "músicas na sua biblioteca"),
                    color = JntColors.TextTertiary,
                    fontSize = 13.sp
                )
            }
        }
        item {
            Row(
                Modifier
                    .padding(horizontal = 20.dp)
                    .fillMaxWidth()
                    .bounceClick {
                        vm.searchFocusTick++
                        nav.goTab(MainTab.Search)
                    }
                    .clip(RoundedCornerShape(16.dp))
                    .background(JntColors.Card)
                    .padding(horizontal = 16.dp, vertical = 15.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Search, contentDescription = null, tint = JntColors.TextSecondary)
                Spacer(Modifier.width(12.dp))
                Text("Música, artista ou álbum", color = JntColors.TextTertiary, fontSize = 15.sp)
            }
        }
        item {
            Row(
                Modifier.padding(horizontal = 20.dp, vertical = 16.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickCard(
                    icon = Icons.Rounded.Favorite,
                    title = "Favoritas",
                    subtitle = plural(favorites.size, "música", "músicas"),
                    modifier = Modifier.weight(1f)
                ) { nav.push(Detail.Favorites) }
                QuickCard(
                    icon = Icons.Rounded.Shuffle,
                    title = "Aleatório",
                    subtitle = "Tocar tudo",
                    modifier = Modifier.weight(1f)
                ) { vm.playShuffled(songs) }
            }
        }

        if (songs.isEmpty()) {
            item {
                EmptyState(
                    Icons.Rounded.MusicNote,
                    "Nenhuma música encontrada",
                    "Copie músicas para o aparelho e elas aparecem aqui automaticamente."
                )
            }
        } else {
            if (recents.isNotEmpty()) {
                item { SectionHeader("Tocadas recentemente") }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(recents, key = { it.id }) { s ->
                            Column(
                                Modifier
                                    .width(132.dp)
                                    .bounceClick { vm.play(recents, recents.indexOf(s).coerceAtLeast(0)) }
                            ) {
                                CoverImage(s, Modifier.size(132.dp), corner = 16.dp, px = 340)
                                Spacer(Modifier.height(8.dp))
                                Text(s.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(s.artist, color = JntColors.TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }

            item {
                SectionHeader("Suas músicas", "Ver todas") {
                    vm.libraryTab = LibraryTab.Songs
                    nav.goTab(MainTab.Library)
                }
            }
            songItems(songs.take(8), ctx, queue = songs, modifier = Modifier.padding(horizontal = 16.dp))

            if (albums.isNotEmpty()) {
                item {
                    SectionHeader("Álbuns", "Ver todos") {
                        vm.libraryTab = LibraryTab.Albums
                        nav.goTab(MainTab.Library)
                    }
                }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(albums.take(12), key = { it.id }) { a ->
                            AlbumCard(a, onClick = { nav.push(Detail.AlbumD(a.id)) }, modifier = Modifier.width(140.dp))
                        }
                    }
                }
            }

            if (artists.isNotEmpty()) {
                item {
                    SectionHeader("Artistas", "Ver todos") {
                        vm.libraryTab = LibraryTab.Artists
                        nav.goTab(MainTab.Library)
                    }
                }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(artists.take(12), key = { it.name }) { a ->
                            ArtistCard(a, onClick = { nav.push(Detail.ArtistD(a.name)) }, modifier = Modifier.width(110.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Row(
        modifier
            .bounceClick(onClick = onClick)
            .clip(RoundedCornerShape(16.dp))
            .background(JntColors.Card)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(42.dp).clip(CircleShape).background(JntColors.CardHigh),
            contentAlignment = Alignment.Center
        ) { Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp)) }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(subtitle, color = JntColors.TextSecondary, fontSize = 12.sp)
        }
    }
}
