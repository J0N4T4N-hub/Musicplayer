package com.jnt.player.ui

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jnt.player.data.*
import com.jnt.player.playback.PlayerController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.Normalizer
import kotlin.random.Random

private val diacritics = Regex("\\p{Mn}+")

fun String.norm(): String =
    Normalizer.normalize(this, Normalizer.Form.NFD).replace(diacritics, "").lowercase()

fun hasAudioPermission(context: Context): Boolean {
    val permission = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }
    return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()
    private val repo = MediaStoreRepository(app)
    private val scope = viewModelScope

    val permissionGranted = MutableStateFlow(hasAudioPermission(app))
    var libraryTab by mutableStateOf(LibraryTab.Songs)
    var searchFocusTick by mutableIntStateOf(0)
    val query = MutableStateFlow("")
    val sortOrder = MutableStateFlow(SortOrder.NAME)
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 8)

    /** null = ainda carregando / sem permissão */
    @OptIn(ExperimentalCoroutinesApi::class)
    val songs: StateFlow<List<Song>?> = permissionGranted
        .flatMapLatest<Boolean, List<Song>?> { granted -> if (granted) repo.observe() else flowOf(null) }
        .stateIn(scope, SharingStarted.Eagerly, null)

    private val songsById: StateFlow<Map<Long, Song>> = songs
        .map { list -> list.orEmpty().associateBy { it.id } }
        .stateIn(scope, SharingStarted.Eagerly, emptyMap())

    private val stats: StateFlow<Map<Long, PlayStatEntity>> = dao.stats()
        .map { list -> list.associateBy { it.songId } }
        .stateIn(scope, SharingStarted.Eagerly, emptyMap())

    private val favoriteOrder: StateFlow<List<Long>> =
        dao.favorites().stateIn(scope, SharingStarted.Eagerly, emptyList())

    val favoriteIds: StateFlow<Set<Long>> = favoriteOrder
        .map { it.toSet() }
        .stateIn(scope, SharingStarted.Eagerly, emptySet())

    val favoriteSongs: StateFlow<List<Song>> = combine(songsById, favoriteOrder) { byId, order ->
        order.mapNotNull { byId[it] }
    }.stateIn(scope, SharingStarted.Eagerly, emptyList())

    val recentlyAdded: StateFlow<List<Song>> = songs
        .map { list -> list.orEmpty().sortedByDescending { it.dateAdded } }
        .flowOn(Dispatchers.Default)
        .stateIn(scope, SharingStarted.Eagerly, emptyList())

    val sortedSongs: StateFlow<List<Song>> = combine(songs, sortOrder, stats) { list, order, st ->
        val all = list.orEmpty()
        when (order) {
            SortOrder.NAME -> all.sortedBy { it.title.lowercase() }
            SortOrder.ARTIST -> all.sortedWith(compareBy<Song>({ it.artist.lowercase() }, { it.title.lowercase() }))
            SortOrder.ALBUM -> all.sortedWith(compareBy<Song>({ it.album.lowercase() }, { it.track }, { it.title.lowercase() }))
            SortOrder.RECENT -> all.sortedByDescending { it.dateAdded }
            SortOrder.MOST_PLAYED -> all.sortedWith(
                compareByDescending<Song> { st[it.id]?.playCount ?: 0 }.thenBy { it.title.lowercase() }
            )
        }
    }.flowOn(Dispatchers.Default).stateIn(scope, SharingStarted.Eagerly, emptyList())

    val albums: StateFlow<List<Album>> = songs.map { list ->
        list.orEmpty().groupBy { it.albumId }.map { (id, group) ->
            val ordered = group.sortedWith(compareBy<Song>({ it.track }, { it.title.lowercase() }))
            val artists = ordered.map { it.artist }.distinct()
            Album(id, ordered.first().album, if (artists.size == 1) artists[0] else "Vários artistas", ordered)
        }.sortedBy { it.name.lowercase() }
    }.flowOn(Dispatchers.Default).stateIn(scope, SharingStarted.Eagerly, emptyList())

    val artists: StateFlow<List<Artist>> = songs.map { list ->
        list.orEmpty().groupBy { it.artist }.map { (name, group) ->
            Artist(name, group.sortedWith(compareBy<Song>({ it.album.lowercase() }, { it.track }, { it.title.lowercase() })))
        }.sortedBy { it.name.lowercase() }
    }.flowOn(Dispatchers.Default).stateIn(scope, SharingStarted.Eagerly, emptyList())

    val playlists: StateFlow<List<PlaylistUi>> =
        combine(dao.playlists(), dao.allPlaylistSongs(), songsById) { pls, links, byId ->
            val grouped = links.groupBy { it.playlistId }
            pls.map { p ->
                PlaylistUi(
                    p.id,
                    p.name,
                    grouped[p.id].orEmpty().sortedBy { it.position }.mapNotNull { byId[it.songId] }
                )
            }
        }.stateIn(scope, SharingStarted.Eagerly, emptyList())

    val recents: StateFlow<List<Song>> = combine(songsById, stats) { byId, st ->
        st.values.sortedByDescending { it.lastPlayed }.mapNotNull { byId[it.songId] }.take(15)
    }.stateIn(scope, SharingStarted.Eagerly, emptyList())

    val searchResults: StateFlow<SearchResults> = combine(songs, albums, artists, query) { list, al, ar, q ->
        val tokens = q.norm().split(' ').filter { it.isNotEmpty() }
        if (tokens.isEmpty()) {
            SearchResults()
        } else {
            fun matches(text: String): Boolean {
                val t = text.norm()
                return tokens.all { t.contains(it) }
            }
            SearchResults(
                songs = list.orEmpty().filter { matches("${it.title} ${it.artist} ${it.album}") }.take(60),
                albums = al.filter { matches("${it.name} ${it.artist}") },
                artists = ar.filter { matches(it.name) }
            )
        }
    }.flowOn(Dispatchers.Default).stateIn(scope, SharingStarted.Eagerly, SearchResults())

    private val controller = PlayerController(app, scope) { id ->
        scope.launch { dao.registerPlay(id, System.currentTimeMillis()) }
    }
    val player = controller.state
    val position = controller.position

    val currentSong: StateFlow<Song?> = combine(
        controller.state.map { it.mediaId }.distinctUntilChanged(),
        songsById
    ) { id, byId -> id?.let { byId[it] } }.stateIn(scope, SharingStarted.Eagerly, null)

    fun refreshPermission() {
        permissionGranted.value = hasAudioPermission(getApplication())
    }

    // ---- Reprodução ----
    fun play(queue: List<Song>, index: Int) = controller.play(queue, index)

    fun playShuffled(queue: List<Song>) {
        if (queue.isNotEmpty()) controller.play(queue, Random.nextInt(queue.size), shuffle = true)
    }

    fun toggle() = controller.toggle()
    fun next() = controller.next()
    fun previous() = controller.previous()
    fun seekTo(ms: Long) = controller.seekTo(ms)
    fun toggleShuffle() = controller.toggleShuffle()
    fun cycleRepeat() = controller.cycleRepeat()

    // ---- Favoritos ----
    fun toggleFavorite(song: Song) {
        scope.launch {
            if (song.id in favoriteIds.value) {
                dao.removeFavorite(song.id)
            } else {
                dao.addFavorite(FavoriteEntity(song.id, System.currentTimeMillis()))
                messages.tryEmit("Adicionada aos favoritos")
            }
        }
    }

    // ---- Playlists ----
    fun createPlaylist(name: String, firstSong: Song? = null) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        scope.launch {
            val id = dao.insertPlaylist(PlaylistEntity(name = clean, createdAt = System.currentTimeMillis()))
            if (firstSong != null) dao.addSongToPlaylist(id, firstSong.id)
            messages.tryEmit("Playlist \"$clean\" criada")
        }
    }

    fun renamePlaylist(id: Long, name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        scope.launch { dao.renamePlaylist(id, clean) }
    }

    fun deletePlaylist(id: Long) {
        scope.launch {
            dao.deletePlaylist(id)
            messages.tryEmit("Playlist excluída")
        }
    }

    fun addToPlaylist(playlist: PlaylistUi, song: Song) {
        scope.launch {
            val added = dao.addSongToPlaylist(playlist.id, song.id)
            messages.tryEmit(if (added) "Adicionada a \"${playlist.name}\"" else "Já está em \"${playlist.name}\"")
        }
    }

    fun removeFromPlaylist(playlistId: Long, song: Song) {
        scope.launch { dao.removeFromPlaylist(playlistId, song.id) }
    }

    fun moveInPlaylist(playlistId: Long, from: Int, to: Int) {
        scope.launch {
            val ids = playlists.value.firstOrNull { it.id == playlistId }?.songs?.map { it.id }?.toMutableList()
                ?: return@launch
            if (from !in ids.indices || to !in ids.indices) return@launch
            ids.add(to, ids.removeAt(from))
            dao.reorder(playlistId, ids)
        }
    }

    override fun onCleared() {
        controller.release()
        super.onCleared()
    }
}
