package com.jnt.player.playback

import android.content.ComponentName
import android.content.Context
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.jnt.player.data.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class PlayerState(
    val mediaId: Long? = null,
    val isPlaying: Boolean = false,
    val shuffle: Boolean = false,
    val repeat: Int = Player.REPEAT_MODE_OFF,
    val durationMs: Long = 0L
)

/** Ponte entre a interface e o PlaybackService (Media3 MediaController). */
class PlayerController(
    private val context: Context,
    scope: CoroutineScope,
    private val onTrackStarted: (Long) -> Unit
) {
    private val _state = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = _state.asStateFlow()

    private val _position = MutableStateFlow(0L)
    val position: StateFlow<Long> = _position.asStateFlow()

    private var controller: MediaController? = null
    private val future: ListenableFuture<MediaController>
    private val waiting = ArrayList<(MediaController) -> Unit>()

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            sync(player)
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            mediaItem?.mediaId?.toLongOrNull()?.let(onTrackStarted)
        }
    }

    init {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            val c = runCatching { future.get() }.getOrNull()
            if (c != null) {
                controller = c
                c.addListener(listener)
                sync(c)
                waiting.forEach { it(c) }
                waiting.clear()
            }
        }, ContextCompat.getMainExecutor(context))

        scope.launch {
            while (true) {
                delay(250)
                controller?.let { if (it.isPlaying) _position.value = it.currentPosition }
            }
        }
    }

    private fun sync(p: Player) {
        _state.value = PlayerState(
            mediaId = p.currentMediaItem?.mediaId?.toLongOrNull(),
            isPlaying = p.playWhenReady &&
                p.playbackState != Player.STATE_ENDED &&
                p.playbackState != Player.STATE_IDLE,
            shuffle = p.shuffleModeEnabled,
            repeat = p.repeatMode,
            durationMs = p.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: 0L
        )
        _position.value = p.currentPosition.coerceAtLeast(0L)
    }

    private fun withController(block: (MediaController) -> Unit) {
        val c = controller
        if (c != null) block(c) else waiting.add(block)
    }

    private fun item(song: Song): MediaItem = MediaItem.Builder()
        .setMediaId(song.id.toString())
        .setUri(song.uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(song.title)
                .setArtist(song.artist)
                .setAlbumTitle(song.album)
                .setArtworkUri(song.uri)
                .build()
        )
        .build()

    fun play(queue: List<Song>, index: Int, shuffle: Boolean? = null) {
        if (queue.isEmpty()) return
        // Limita a fila para não estourar o limite de dados entre processos
        val maxSize = 800
        val from = if (queue.size > maxSize) (index - 100).coerceIn(0, queue.size - maxSize) else 0
        val window = queue.subList(from, minOf(queue.size, from + maxSize))
        val start = (index - from).coerceIn(0, window.lastIndex)
        withController { c ->
            c.setMediaItems(window.map(::item), start, 0L)
            if (shuffle != null) c.shuffleModeEnabled = shuffle
            c.prepare()
            c.play()
        }
    }

    fun toggle() = withController { c ->
        if (c.playWhenReady && c.playbackState != Player.STATE_ENDED) {
            c.pause()
        } else {
            if (c.playbackState == Player.STATE_ENDED) c.seekTo(0L)
            c.play()
        }
    }

    fun next() = withController { it.seekToNext() }

    fun previous() = withController { it.seekToPrevious() }

    fun seekTo(ms: Long) = withController {
        it.seekTo(ms)
        _position.value = ms
    }

    fun toggleShuffle() = withController { it.shuffleModeEnabled = !it.shuffleModeEnabled }

    fun cycleRepeat() = withController {
        it.repeatMode = when (it.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun release() {
        controller?.removeListener(listener)
        MediaController.releaseFuture(future)
        controller = null
    }
}
