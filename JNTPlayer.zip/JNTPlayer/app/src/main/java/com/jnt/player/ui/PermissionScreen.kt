package com.jnt.player.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jnt.player.ui.theme.JntColors

@Composable
fun PermissionScreen(vm: MainViewModel) {
    val context = LocalContext.current
    var denied by remember { mutableStateOf(false) }

    val permissions = remember {
        buildList {
            if (Build.VERSION.SDK_INT >= 33) {
                add(Manifest.permission.READ_MEDIA_AUDIO)
                add(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }.toTypedArray()
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        vm.refreshPermission()
        if (!vm.permissionGranted.value) denied = true
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(JntColors.Bg)
            .systemBarsPadding()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        JntLogo()
        Spacer(Modifier.height(48.dp))
        Box(
            Modifier.size(88.dp).clip(CircleShape).background(JntColors.Card),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.LibraryMusic, contentDescription = null, tint = Color.White, modifier = Modifier.size(40.dp))
        }
        Spacer(Modifier.height(28.dp))
        Text(
            "Sua biblioteca, pronta para tocar",
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "Para encontrar automaticamente as músicas do seu aparelho, o JNT Player precisa de acesso aos arquivos de áudio. Nada sai do seu celular.",
            color = JntColors.TextSecondary,
            fontSize = 15.sp,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(36.dp))
        PillButton(
            text = if (denied) "Tentar novamente" else "Permitir acesso às músicas",
            icon = Icons.Rounded.LibraryMusic,
            filled = true,
            onClick = { launcher.launch(permissions) }
        )
        if (denied) {
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = {
                context.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                )
            }) {
                Text("Abrir configurações do app", color = JntColors.TextSecondary)
            }
        }
    }
}
