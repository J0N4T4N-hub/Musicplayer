package com.jnt.player.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Carrega capas de álbum direto do arquivo de áudio, com cache em memória. */
object CoverLoader {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val misses: MutableSet<String> = java.util.Collections.synchronizedSet(HashSet())

    suspend fun load(context: Context, songUri: Uri, px: Int): Bitmap? =
        withContext(Dispatchers.IO) { loadBlocking(context, songUri, px) }

    fun loadBlocking(context: Context, songUri: Uri, px: Int): Bitmap? {
        val key = "$songUri#$px"
        cache.get(key)?.let { return it }
        if (key in misses) return null
        val bitmap = fromThumbnail(context, songUri, px) ?: fromEmbedded(context, songUri, px)
        if (bitmap != null) cache.put(key, bitmap) else misses.add(key)
        return bitmap
    }

    private fun fromThumbnail(context: Context, uri: Uri, px: Int): Bitmap? {
        if (Build.VERSION.SDK_INT < 29) return null
        return runCatching { context.contentResolver.loadThumbnail(uri, Size(px, px), null) }.getOrNull()
    }

    private fun fromEmbedded(context: Context, uri: Uri, px: Int): Bitmap? = runCatching {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val data = retriever.embeddedPicture
            if (data == null) null else decode(data, px)
        } finally {
            retriever.release()
        }
    }.getOrNull()

    private fun decode(data: ByteArray, px: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= px && bounds.outHeight / (sample * 2) >= px) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(data, 0, data.size, options)
    }
}
