package com.jnt.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jnt.player.data.Song
import com.jnt.player.ui.theme.JntColors
import kotlinx.coroutines.launch

@Composable
fun JntApp(vm: MainViewModel) {
    val granted by vm.permissionGranted.collectAsStateWithLifecycle()
    val songs by vm.songs.collectAsStateWithLifecycle()
    when {
        !granted -> PermissionScreen(vm)
        songs == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp)
        }
        else -> MainContent(vm)
    }
}

@Composable
private fun MainContent(vm: MainViewModel) {
    val current by vm.currentSong.collectAsStateWithLifecycle()
    val playerState by vm.player.collectAsStateWithLifecycle()
    val favs by vm.favoriteIds.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()

    var tab by rememberSaveable { mutableStateOf(MainTab.Home) }
    val stack = remember { mutableStateListOf<Detail>() }
    var playerOpen by rememberSaveable { mutableStateOf(false) }
    var pickerSong by remember { mutableStateOf<Song?>(null) }
    var lastSong by remember { mutableStateOf<Song?>(null) }
    var shownDetail by remember { mutableStateOf<Detail?>(null) }

    LaunchedEffect(current) { if (current != null) lastSong = current }
    val topDetail = stack.lastOrNull()
    LaunchedEffect(topDetail) { if (topDetail != null) shownDetail = topDetail }

    val nav = remember {
        Nav(
            goTab = { t ->
                stack.clear()
                tab = t
            },
            push = { d -> stack.add(d) },
            pickPlaylist = { s -> pickerSong = s }
        )
    }
    val ctx = ListCtx(vm, nav, current?.id, favs)

    BackHandler(enabled = stack.isNotEmpty()) { stack.removeAt(stack.lastIndex) }
    BackHandler(enabled = playerOpen) { playerOpen = false }

    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        vm.messages.collect { message ->
            snackbar.currentSnackbarData?.dismiss()
            scope.launch { snackbar.showSnackbar(message, duration = SnackbarDuration.Short) }
        }
    }

    Box(Modifier.fillMaxSize().background(JntColors.Bg)) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                AnimatedContent(
                    targetState = tab,
                    transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(160)) },
                    label = "tabs"
                ) { t ->
                    when (t) {
                        MainTab.Home -> HomeScreen(vm, nav, ctx)
                        MainTab.Search -> SearchScreen(vm, nav, ctx)
                        MainTab.Library -> LibraryScreen(vm, nav, ctx)
                    }
                }
                AnimatedVisibility(
                    visible = topDetail != null,
                    enter = slideInHorizontally(tween(300, easing = FastOutSlowInEasing)) { it / 3 } + fadeIn(tween(300)),
                    exit = slideOutHorizontally(tween(250)) { it / 3 } + fadeOut(tween(200))
                ) {
                    Box(Modifier.fillMaxSize().background(JntColors.Bg)) {
                        (topDetail ?: shownDetail)?.let { d ->
                            DetailHost(d, vm, ctx, onBack = { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) })
                        }
                    }
                }
            }
            current?.let { song ->
                MiniPlayer(
                    song = song,
                    playing = playerState.isPlaying,
                    durationMs = playerState.durationMs.takeIf { it > 0 } ?: song.durationMs,
                    vm = vm,
                    onOpen = { playerOpen = true }
                )
            }
            BottomBar(tab) { t ->
                stack.clear()
                tab = t
            }
        }

        AnimatedVisibility(
            visible = playerOpen && lastSong != null,
            enter = slideInVertically(tween(380, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(300)),
            exit = slideOutVertically(tween(300)) { it } + fadeOut(tween(250))
        ) {
            val song = current ?: lastSong
            if (song != null) {
                PlayerScreen(
                    song = song,
                    state = playerState,
                    isFavorite = song.id in favs,
                    vm = vm,
                    onClose = { playerOpen = false },
                    onAddToPlaylist = { pickerSong = song }
                )
            }
        }

        SnackbarHost(
            hostState = snackbar,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = if (playerOpen) 24.dp else 150.dp),
            snackbar = { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = JntColors.CardHigh,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(14.dp)
                )
            }
        )
    }

    pickerSong?.let { song ->
        PlaylistPickerSheet(
            song = song,
            playlists = playlists,
            onPick = { p ->
                vm.addToPlaylist(p, song)
                pickerSong = null
            },
            onCreate = { name ->
                vm.createPlaylist(name, song)
                pickerSong = null
            },
            onDismiss = { pickerSong = null }
        )
    }
}

@Composable
private fun MiniPlayer(song: Song, playing: Boolean, durationMs: Long, vm: MainViewModel, onOpen: () -> Unit) {
    val position by vm.position.collectAsStateWithLifecycle()
    val fraction = if (durationMs > 0) (position.toFloat() / durationMs).coerceIn(0f, 1f) else 0f

    Column(
        Modifier
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .fillMaxWidth()
            .bounceClick(onClick = onOpen)
            .clip(RoundedCornerShape(16.dp))
            .background(JntColors.Card)
    ) {
        Row(
            Modifier.padding(start = 8.dp, end = 4.dp, top = 8.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AnimatedContent(
                targetState = song,
                transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) },
                modifier = Modifier.weight(1f),
                label = "miniSong"
            ) { s ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CoverImage(s, Modifier.size(44.dp), corner = 10.dp, px = 140)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            s.title,
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            s.artist,
                            color = JntColors.TextSecondary,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
            IconButton(onClick = { vm.toggle() }) {
                Icon(
                    if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = if (playing) "Pausar" else "Reproduzir",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }
            IconButton(onClick = { vm.next() }) {
                Icon(Icons.Rounded.SkipNext, contentDescription = "Próxima", tint = Color.White)
            }
        }
        Box(
            Modifier
                .padding(horizontal = 12.dp)
                .padding(bottom = 8.dp)
                .fillMaxWidth()
                .height(2.dp)
                .clip(RoundedCornerShape(1.dp))
                .background(JntColors.Outline)
        ) {
            Box(Modifier.fillMaxWidth(fraction).fillMaxHeight().background(Color.White))
        }
    }
}

@Composable
private fun BottomBar(selected: MainTab, onSelect: (MainTab) -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF0C0C0C))) {
        HorizontalDivider(color = JntColors.Outline, thickness = 0.5.dp)
        Row(Modifier.navigationBarsPadding().height(62.dp).fillMaxWidth()) {
            BarItem(Icons.Rounded.Home, "Início", selected == MainTab.Home, Modifier.weight(1f)) { onSelect(MainTab.Home) }
            BarItem(Icons.Rounded.Search, "Buscar", selected == MainTab.Search, Modifier.weight(1f)) { onSelect(MainTab.Search) }
            BarItem(Icons.Rounded.LibraryMusic, "Biblioteca", selected == MainTab.Library, Modifier.weight(1f)) { onSelect(MainTab.Library) }
        }
    }
}

@Composable
private fun BarItem(icon: ImageVector, label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val color by animateColorAsState(if (selected) Color.White else JntColors.TextTertiary, label = "barColor")
    Column(
        modifier.fillMaxHeight().bounceClick(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, contentDescription = label, tint = color, modifier = Modifier.size(26.dp))
        Spacer(Modifier.height(3.dp))
        Text(label, color = color, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}
