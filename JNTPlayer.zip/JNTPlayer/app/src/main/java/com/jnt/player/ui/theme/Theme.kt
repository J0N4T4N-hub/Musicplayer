package com.jnt.player.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object JntColors {
    val Bg = Color(0xFF080808)
    val Card = Color(0xFF151515)
    val CardHigh = Color(0xFF1F1F1F)
    val Outline = Color(0xFF2B2B2B)
    val TextPrimary = Color(0xFFFFFFFF)
    val TextSecondary = Color(0xFFA3A3A3)
    val TextTertiary = Color(0xFF6B6B6B)
}

private val JntScheme = darkColorScheme(
    primary = Color.White,
    onPrimary = Color.Black,
    secondary = Color(0xFFD0D0D0),
    onSecondary = Color.Black,
    background = JntColors.Bg,
    onBackground = Color.White,
    surface = JntColors.Card,
    onSurface = Color.White,
    surfaceVariant = JntColors.CardHigh,
    onSurfaceVariant = JntColors.TextSecondary,
    surfaceContainer = JntColors.CardHigh,
    surfaceContainerHigh = JntColors.CardHigh,
    surfaceContainerHighest = JntColors.CardHigh,
    outline = JntColors.Outline,
    outlineVariant = JntColors.Outline,
    error = Color(0xFFFF6B6B)
)

private val JntTypography = Typography(
    headlineLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 30.sp, letterSpacing = (-0.5).sp),
    headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 26.sp, letterSpacing = (-0.3).sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp, letterSpacing = (-0.2).sp),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 20.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
    bodyLarge = TextStyle(fontWeight = FontWeight.Normal, fontSize = 16.sp),
    bodyMedium = TextStyle(fontWeight = FontWeight.Normal, fontSize = 14.sp),
    bodySmall = TextStyle(fontWeight = FontWeight.Normal, fontSize = 12.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, letterSpacing = 0.5.sp)
)

private val JntShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun JntTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = JntScheme,
        typography = JntTypography,
        shapes = JntShapes,
        content = content
    )
}
