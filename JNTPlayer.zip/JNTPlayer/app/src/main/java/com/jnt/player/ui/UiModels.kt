package com.jnt.player.ui

import com.jnt.player.data.Song

enum class MainTab { Home, Search, Library }

enum class LibraryTab(val label: String) {
    Songs("Músicas"),
    Albums("Álbuns"),
    Artists("Artistas"),
    Favorites("Favoritas"),
    Playlists("Playlists")
}

sealed interface Detail {
    data class AlbumD(val id: Long) : Detail
    data class ArtistD(val name: String) : Detail
    data class PlaylistD(val id: Long) : Detail
    data object Favorites : Detail
}

class Nav(
    val goTab: (MainTab) -> Unit,
    val push: (Detail) -> Unit,
    val pickPlaylist: (Song) -> Unit
)

class ListCtx(
    val vm: MainViewModel,
    val nav: Nav,
    val currentId: Long?,
    val favs: Set<Long>
)
