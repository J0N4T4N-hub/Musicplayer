package com.jnt.player.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay

@Composable
fun SearchScreen(vm: MainViewModel, nav: Nav, ctx: ListCtx) {
    val query by vm.query.collectAsStateWithLifecycle()
    val results by vm.searchResults.collectAsStateWithLifecycle()
    val focus = remember { FocusRequester() }

    LaunchedEffect(vm.searchFocusTick) {
        if (vm.searchFocusTick > 0) {
            delay(250)
            runCatching { focus.requestFocus() }
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text(
            "Buscar",
            color = Color.White,
            style = MaterialTheme.typography.headlineLarge,
            modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 12.dp)
        )
        SearchField(
            value = query,
            onValueChange = { vm.query.value = it },
            modifier = Modifier.padding(horizontal = 20.dp).fillMaxWidth().focusRequester(focus)
        )
        Spacer(Modifier.height(8.dp))
        when {
            query.isBlank() -> EmptyState(
                Icons.Rounded.Search,
                "Encontre sua música",
                "Pesquise pelo nome da música, do artista ou do álbum."
            )
            results.isEmpty -> EmptyState(Icons.Rounded.Search, "Nada encontrado", "Tente outro termo de busca.")
            else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
                if (results.songs.isNotEmpty()) {
                    item { SectionHeader("Músicas") }
                    songItems(results.songs, ctx, modifier = Modifier.padding(horizontal = 16.dp))
                }
                if (results.albums.isNotEmpty()) {
                    item { SectionHeader("Álbuns") }
                    item {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 20.dp),
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            items(results.albums, key = { it.id }) { a ->
                                AlbumCard(a, onClick = { nav.push(Detail.AlbumD(a.id)) }, modifier = Modifier.width(140.dp))
                            }
                        }
                    }
                }
                if (results.artists.isNotEmpty()) {
                    item { SectionHeader("Artistas") }
                    item {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 20.dp),
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            items(results.artists, key = { it.name }) { a ->
                                ArtistCard(a, onClick = { nav.push(Detail.ArtistD(a.name)) }, modifier = Modifier.width(110.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
