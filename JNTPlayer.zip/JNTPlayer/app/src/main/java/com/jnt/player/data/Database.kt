package com.jnt.player.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "favorites")
data class FavoriteEntity(@PrimaryKey val songId: Long, val addedAt: Long)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long
)

@Entity(
    tableName = "playlist_songs",
    foreignKeys = [ForeignKey(
        entity = PlaylistEntity::class,
        parentColumns = ["id"],
        childColumns = ["playlistId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index(value = ["playlistId", "songId"], unique = true)]
)
data class PlaylistSongEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long,
    val songId: Long,
    val position: Int
)

@Entity(tableName = "play_stats")
data class PlayStatEntity(@PrimaryKey val songId: Long, val playCount: Int, val lastPlayed: Long)

@Dao
abstract class AppDao {
    @Query("SELECT songId FROM favorites ORDER BY addedAt DESC")
    abstract fun favorites(): Flow<List<Long>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun addFavorite(f: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE songId = :songId")
    abstract suspend fun removeFavorite(songId: Long)

    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    abstract fun playlists(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlist_songs")
    abstract fun allPlaylistSongs(): Flow<List<PlaylistSongEntity>>

    @Insert
    abstract suspend fun insertPlaylist(p: PlaylistEntity): Long

    @Query("UPDATE playlists SET name = :name WHERE id = :id")
    abstract suspend fun renamePlaylist(id: Long, name: String)

    @Query("DELETE FROM playlists WHERE id = :id")
    abstract suspend fun deletePlaylist(id: Long)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    abstract suspend fun insertPlaylistSong(e: PlaylistSongEntity): Long

    @Query("SELECT COALESCE(MAX(position), -1) + 1 FROM playlist_songs WHERE playlistId = :pid")
    abstract suspend fun nextPosition(pid: Long): Int

    @Query("DELETE FROM playlist_songs WHERE playlistId = :pid AND songId = :sid")
    abstract suspend fun removeFromPlaylist(pid: Long, sid: Long)

    @Query("UPDATE playlist_songs SET position = :pos WHERE playlistId = :pid AND songId = :sid")
    abstract suspend fun setPosition(pid: Long, sid: Long, pos: Int)

    @Transaction
    open suspend fun addSongToPlaylist(pid: Long, sid: Long): Boolean {
        val pos = nextPosition(pid)
        return insertPlaylistSong(PlaylistSongEntity(playlistId = pid, songId = sid, position = pos)) != -1L
    }

    @Transaction
    open suspend fun reorder(pid: Long, songIds: List<Long>) {
        songIds.forEachIndexed { index, id -> setPosition(pid, id, index) }
    }

    @Query("SELECT * FROM play_stats")
    abstract fun stats(): Flow<List<PlayStatEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    abstract suspend fun insertStat(s: PlayStatEntity)

    @Query("UPDATE play_stats SET playCount = playCount + 1, lastPlayed = :t WHERE songId = :id")
    abstract suspend fun bumpStat(id: Long, t: Long)

    @Transaction
    open suspend fun registerPlay(id: Long, t: Long) {
        insertStat(PlayStatEntity(id, 0, t))
        bumpStat(id, t)
    }
}

@Database(
    entities = [FavoriteEntity::class, PlaylistEntity::class, PlaylistSongEntity::class, PlayStatEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "jnt.db")
                .build()
                .also { instance = it }
        }
    }
}
