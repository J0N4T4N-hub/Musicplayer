package com.jnt.player.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jnt.player.data.SortOrder
import com.jnt.player.ui.theme.JntColors

@Composable
fun LibraryScreen(vm: MainViewModel, nav: Nav, ctx: ListCtx) {
    val tab = vm.libraryTab
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text(
            "Biblioteca",
            color = Color.White,
            style = MaterialTheme.typography.headlineLarge,
            modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 12.dp)
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(LibraryTab.entries.toList()) { t ->
                JntChip(t.label, t == tab) { vm.libraryTab = t }
            }
        }
        Spacer(Modifier.height(12.dp))
        AnimatedContent(
            targetState = tab,
            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(150)) },
            label = "libraryTab"
        ) { t ->
            when (t) {
                LibraryTab.Songs -> SongsTab(vm, ctx)
                LibraryTab.Albums -> AlbumsTab(vm, nav)
                LibraryTab.Artists -> ArtistsTab(vm, nav)
                LibraryTab.Favorites -> FavoritesTab(vm, ctx)
                LibraryTab.Playlists -> PlaylistsTab(vm, nav)
            }
        }
    }
}

@Composable
private fun SongsTab(vm: MainViewModel, ctx: ListCtx) {
    val songs by vm.sortedSongs.collectAsStateWithLifecycle()
    val order by vm.sortOrder.collectAsStateWithLifecycle()
    var menu by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 4.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box {
                    Row(
                        Modifier
                            .bounceClick { menu = true }
                            .clip(CircleShape)
                            .background(JntColors.Card)
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Sort, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(order.label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        SortOrder.entries.forEach { o ->
                            DropdownMenuItem(
                                text = { Text(o.label) },
                                trailingIcon = { if (o == order) Icon(Icons.Rounded.Check, contentDescription = null) },
                                onClick = {
                                    vm.sortOrder.value = o
                                    menu = false
                                }
                            )
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                Text(plural(songs.size, "música", "músicas"), color = JntColors.TextSecondary, fontSize = 13.sp)
                IconButton(onClick = { vm.playShuffled(songs) }) {
                    Icon(Icons.Rounded.Shuffle, contentDescription = "Tocar aleatório")
                }
            }
        }
        if (songs.isEmpty()) {
            item {
                EmptyState(
                    Icons.Rounded.MusicNote,
                    "Nenhuma música encontrada",
                    "Copie músicas para o aparelho e elas aparecem aqui automaticamente."
                )
            }
        } else {
            songItems(songs, ctx, modifier = Modifier.padding(horizontal = 16.dp))
        }
    }
}

@Composable
private fun AlbumsTab(vm: MainViewModel, nav: Nav) {
    val albums by vm.albums.collectAsStateWithLifecycle()
    if (albums.isEmpty()) {
        EmptyState(Icons.Rounded.Album, "Nenhum álbum", "Os álbuns aparecem quando houver músicas no aparelho.")
        return
    }
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        items(albums, key = { it.id }) { a ->
            AlbumCard(a, onClick = { nav.push(Detail.AlbumD(a.id)) })
        }
    }
}

@Composable
private fun ArtistsTab(vm: MainViewModel, nav: Nav) {
    val artists by vm.artists.collectAsStateWithLifecycle()
    if (artists.isEmpty()) {
        EmptyState(Icons.Rounded.Person, "Nenhum artista", "Os artistas aparecem quando houver músicas no aparelho.")
        return
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp)) {
        items(artists, key = { it.name }) { a ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { nav.push(Detail.ArtistD(a.name)) }
                    .padding(horizontal = 4.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CoverImage(a.songs.first(), Modifier.size(56.dp), corner = 28.dp, px = 160)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(a.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        "${plural(a.albumCount, "álbum", "álbuns")} • ${plural(a.songs.size, "música", "músicas")}",
                        color = JntColors.TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun FavoritesTab(vm: MainViewModel, ctx: ListCtx) {
    val favorites by vm.favoriteSongs.collectAsStateWithLifecycle()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        if (favorites.isEmpty()) {
            item {
                EmptyState(
                    Icons.Rounded.FavoriteBorder,
                    "Sem favoritas ainda",
                    "Toque no coração no player ou no menu de uma música para favoritar."
                )
            }
        } else {
            item {
                Row(
                    Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(plural(favorites.size, "música", "músicas"), color = JntColors.TextSecondary, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    IconButton(onClick = { vm.playShuffled(favorites) }) {
                        Icon(Icons.Rounded.Shuffle, contentDescription = "Tocar aleatório")
                    }
                }
            }
            songItems(favorites, ctx, modifier = Modifier.padding(horizontal = 16.dp))
        }
    }
}

@Composable
private fun PlaylistsTab(vm: MainViewModel, nav: Nav) {
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    var creating by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp)) {
        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { creating = true }
                    .padding(horizontal = 4.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)).background(JntColors.CardHigh),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Add, contentDescription = null, tint = Color.White) }
                Spacer(Modifier.width(14.dp))
                Text("Nova playlist", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            }
        }
        if (playlists.isEmpty()) {
            item {
                EmptyState(
                    Icons.Rounded.QueueMusic,
                    "Nenhuma playlist",
                    "Crie uma playlist e adicione suas músicas favoritas."
                )
            }
        }
        items(playlists, key = { it.id }) { p ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { nav.push(Detail.PlaylistD(p.id)) }
                    .padding(horizontal = 4.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CoverImage(p.songs.firstOrNull(), Modifier.size(56.dp), corner = 12.dp, px = 160)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(p.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(plural(p.songs.size, "música", "músicas"), color = JntColors.TextSecondary, fontSize = 13.sp)
                }
                IconButton(onClick = { vm.play(p.songs, 0) }, enabled = p.songs.isNotEmpty()) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = "Reproduzir playlist")
                }
            }
        }
    }

    if (creating) {
        NameDialog(
            title = "Nova playlist",
            initial = "",
            confirm = "Criar",
            onConfirm = { name ->
                creating = false
                vm.createPlaylist(name)
            },
            onDismiss = { creating = false }
        )
    }
}
