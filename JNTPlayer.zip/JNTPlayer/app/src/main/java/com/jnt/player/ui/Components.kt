package com.jnt.player.ui

import android.graphics.Bitmap
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jnt.player.data.Album
import com.jnt.player.data.Artist
import com.jnt.player.data.CoverLoader
import com.jnt.player.data.PlaylistUi
import com.jnt.player.data.Song
import com.jnt.player.ui.theme.JntColors

fun plural(n: Int, one: String, many: String) = "$n ${if (n == 1) one else many}"

fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(total / 60, total % 60)
}

/** Feedback visual ao tocar: leve redução de escala com mola. */
fun Modifier.bounceClick(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.95f else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 500f),
        label = "press"
    )
    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(interactionSource = source, indication = null, enabled = enabled, onClick = onClick)
}

@Composable
fun JntLogo(modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Brush.linearGradient(listOf(Color.White, Color(0xFF8E8E8E)))),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.GraphicEq, contentDescription = null, tint = Color.Black, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(10.dp))
        Text("JNT", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp, letterSpacing = 1.sp)
        Spacer(Modifier.width(6.dp))
        Text(
            "PLAYER",
            color = JntColors.TextSecondary,
            fontWeight = FontWeight.Medium,
            fontSize = 12.sp,
            letterSpacing = 3.sp
        )
    }
}

@Composable
fun CoverImage(song: Song?, modifier: Modifier = Modifier, corner: Dp = 12.dp, px: Int = 320) {
    val context = LocalContext.current
    val bitmap by produceState<Bitmap?>(initialValue = null, song?.id, px) {
        value = if (song == null) null else CoverLoader.load(context, song.uri, px)
    }
    Box(
        modifier
            .clip(RoundedCornerShape(corner))
            .background(Brush.linearGradient(listOf(Color(0xFF2C2C2C), Color(0xFF161616)))),
        contentAlignment = Alignment.Center
    ) {
        Crossfade(targetState = bitmap, label = "cover") { bmp ->
            if (bmp != null) {
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.Rounded.MusicNote,
                        contentDescription = null,
                        tint = JntColors.TextTertiary,
                        modifier = Modifier.fillMaxSize(0.4f)
                    )
                }
            }
        }
    }
}

@Composable
fun SongRow(
    song: Song,
    current: Boolean,
    favorite: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onAddToPlaylist: () -> Unit,
    modifier: Modifier = Modifier,
    trailing: (@Composable RowScope.() -> Unit)? = null
) {
    var menu by remember { mutableStateOf(false) }
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CoverImage(song, Modifier.size(52.dp), corner = 10.dp, px = 160)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                song.artist,
                color = JntColors.TextSecondary,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (current) {
            Icon(
                Icons.Rounded.GraphicEq,
                contentDescription = "Tocando",
                tint = Color.White,
                modifier = Modifier.padding(horizontal = 6.dp).size(20.dp)
            )
        }
        if (trailing != null) {
            trailing(this)
        } else {
            Box {
                IconButton(onClick = { menu = true }) {
                    Icon(Icons.Rounded.MoreVert, contentDescription = "Mais opções", tint = JntColors.TextSecondary)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text(if (favorite) "Remover dos favoritos" else "Favoritar") },
                        leadingIcon = {
                            Icon(if (favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null)
                        },
                        onClick = { menu = false; onToggleFavorite() }
                    )
                    DropdownMenuItem(
                        text = { Text("Adicionar à playlist") },
                        leadingIcon = { Icon(Icons.Rounded.PlaylistAdd, null) },
                        onClick = { menu = false; onAddToPlaylist() }
                    )
                }
            }
        }
    }
}

fun LazyListScope.songItems(
    songs: List<Song>,
    ctx: ListCtx,
    queue: List<Song> = songs,
    modifier: Modifier = Modifier
) {
    itemsIndexed(songs, key = { _, s -> s.id }) { _, s ->
        SongRow(
            song = s,
            current = s.id == ctx.currentId,
            favorite = s.id in ctx.favs,
            onClick = { ctx.vm.play(queue, queue.indexOfFirst { it.id == s.id }.coerceAtLeast(0)) },
            onToggleFavorite = { ctx.vm.toggleFavorite(s) },
            onAddToPlaylist = { ctx.nav.pickPlaylist(s) },
            modifier = modifier.animateItem()
        )
    }
}

@Composable
fun SectionHeader(title: String, actionLabel: String? = null, onAction: () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = Color.White, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
        if (actionLabel != null) {
            Text(
                actionLabel,
                color = JntColors.TextSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.clip(CircleShape).clickable(onClick = onAction).padding(horizontal = 10.dp, vertical = 6.dp)
            )
        }
    }
}

@Composable
fun AlbumCard(album: Album, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.bounceClick(onClick = onClick)) {
        CoverImage(album.songs.first(), Modifier.fillMaxWidth().aspectRatio(1f), corner = 16.dp, px = 360)
        Spacer(Modifier.height(10.dp))
        Text(
            album.name,
            color = Color.White,
            fontWeight = FontWeight.SemiBold,
            fontSize = 15.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            album.artist,
            color = JntColors.TextSecondary,
            fontSize = 13.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun ArtistCard(artist: Artist, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.bounceClick(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        CoverImage(artist.songs.first(), Modifier.fillMaxWidth().aspectRatio(1f), corner = 200.dp, px = 300)
        Spacer(Modifier.height(10.dp))
        Text(
            artist.name,
            color = Color.White,
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun JntChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) Color.White else JntColors.Card, label = "chipBg")
    val fg by animateColorAsState(if (selected) Color.Black else Color.White, label = "chipFg")
    Box(
        Modifier
            .bounceClick(onClick = onClick)
            .clip(CircleShape)
            .background(bg)
            .padding(horizontal = 18.dp, vertical = 9.dp)
    ) {
        Text(text, color = fg, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun PillButton(
    text: String,
    icon: ImageVector,
    filled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val fg = if (filled) Color.Black else Color.White
    Row(
        modifier
            .bounceClick(onClick = onClick)
            .clip(CircleShape)
            .background(if (filled) Color.White else Color.Transparent)
            .then(if (filled) Modifier else Modifier.border(1.dp, JntColors.Outline, CircleShape))
            .padding(horizontal = 22.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, color = fg, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
}

@Composable
fun EmptyState(icon: ImageVector, title: String, subtitle: String, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth().padding(horizontal = 40.dp, vertical = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(72.dp).clip(CircleShape).background(JntColors.Card),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = JntColors.TextSecondary, modifier = Modifier.size(32.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(subtitle, color = JntColors.TextSecondary, fontSize = 14.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun SearchField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current
    TextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier,
        singleLine = true,
        placeholder = { Text("Música, artista ou álbum") },
        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
        trailingIcon = {
            if (value.isNotEmpty()) {
                IconButton(onClick = { onValueChange("") }) {
                    Icon(Icons.Rounded.Close, contentDescription = "Limpar")
                }
            }
        },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
        shape = RoundedCornerShape(16.dp),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = JntColors.Card,
            unfocusedContainerColor = JntColors.Card,
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            cursorColor = Color.White,
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            focusedLeadingIconColor = Color.White,
            unfocusedLeadingIconColor = JntColors.TextSecondary,
            focusedTrailingIconColor = Color.White,
            unfocusedTrailingIconColor = JntColors.TextSecondary,
            focusedPlaceholderColor = JntColors.TextTertiary,
            unfocusedPlaceholderColor = JntColors.TextTertiary
        )
    )
}

@Composable
fun NameDialog(
    title: String,
    initial: String,
    confirm: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = JntColors.Card,
        titleContentColor = Color.White,
        textContentColor = Color.White,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                placeholder = { Text("Nome da playlist") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.White,
                    unfocusedBorderColor = JntColors.Outline,
                    cursorColor = Color.White,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
        },
        confirmButton = {
            TextButton(onClick = { if (text.isNotBlank()) onConfirm(text.trim()) }) {
                Text(confirm, color = Color.White, fontWeight = FontWeight.SemiBold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar", color = JntColors.TextSecondary) }
        }
    )
}

@Composable
fun PlaylistPickerSheet(
    song: Song,
    playlists: List<PlaylistUi>,
    onPick: (PlaylistUi) -> Unit,
    onCreate: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var creating by remember { mutableStateOf(false) }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = JntColors.Card,
        contentColor = Color.White
    ) {
        Text(
            "Adicionar à playlist",
            color = Color.White,
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
        )
        Text(
            song.title,
            color = JntColors.TextSecondary,
            fontSize = 13.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 24.dp)
        )
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.heightIn(max = 420.dp)) {
            item {
                Row(
                    Modifier.fillMaxWidth().clickable { creating = true }.padding(horizontal = 24.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)).background(JntColors.CardHigh),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Rounded.Add, contentDescription = null, tint = Color.White) }
                    Spacer(Modifier.width(14.dp))
                    Text("Nova playlist", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                }
            }
            items(playlists, key = { it.id }) { p ->
                val already = p.songs.any { it.id == song.id }
                Row(
                    Modifier.fillMaxWidth().clickable { onPick(p) }.padding(horizontal = 24.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CoverImage(p.songs.firstOrNull(), Modifier.size(48.dp), corner = 10.dp, px = 140)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(plural(p.songs.size, "música", "músicas"), color = JntColors.TextSecondary, fontSize = 13.sp)
                    }
                    if (already) Icon(Icons.Rounded.Check, contentDescription = "Já adicionada", tint = Color.White)
                }
            }
        }
        Spacer(Modifier.height(28.dp))
    }
    if (creating) {
        NameDialog(
            title = "Nova playlist",
            initial = "",
            confirm = "Criar",
            onConfirm = { name -> creating = false; onCreate(name) },
            onDismiss = { creating = false }
        )
    }
}
