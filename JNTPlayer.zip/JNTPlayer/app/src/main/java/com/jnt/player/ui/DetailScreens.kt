package com.jnt.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jnt.player.data.Song
import com.jnt.player.ui.theme.JntColors

@Composable
fun DetailHost(detail: Detail, vm: MainViewModel, ctx: ListCtx, onBack: () -> Unit) {
    when (detail) {
        is Detail.AlbumD -> {
            val albums by vm.albums.collectAsStateWithLifecycle()
            val album = albums.firstOrNull { it.id == detail.id }
            if (album == null) {
                LaunchedEffect(Unit) { onBack() }
            } else {
                CollectionScreen(
                    title = album.name,
                    subtitle = "${album.artist} • ${plural(album.songs.size, "música", "músicas")}",
                    songs = album.songs,
                    coverSong = album.songs.first(),
                    heroIcon = null,
                    ctx = ctx,
                    onBack = onBack
                )
            }
        }

        is Detail.ArtistD -> {
            val artists by vm.artists.collectAsStateWithLifecycle()
            val artist = artists.firstOrNull { it.name == detail.name }
            if (artist == null) {
                LaunchedEffect(Unit) { onBack() }
            } else {
                CollectionScreen(
                    title = artist.name,
                    subtitle = "${plural(artist.albumCount, "álbum", "álbuns")} • ${plural(artist.songs.size, "música", "músicas")}",
                    songs = artist.songs,
                    coverSong = artist.songs.first(),
                    heroIcon = null,
                    ctx = ctx,
                    onBack = onBack
                )
            }
        }

        is Detail.Favorites -> {
            val favorites by vm.favoriteSongs.collectAsStateWithLifecycle()
            CollectionScreen(
                title = "Músicas favoritas",
                subtitle = plural(favorites.size, "música", "músicas"),
                songs = favorites,
                coverSong = null,
                heroIcon = Icons.Rounded.Favorite,
                ctx = ctx,
                onBack = onBack
            )
        }

        is Detail.PlaylistD -> PlaylistDetail(detail.id, vm, ctx, onBack)
    }
}

@Composable
private fun PlaylistDetail(id: Long, vm: MainViewModel, ctx: ListCtx, onBack: () -> Unit) {
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val playlist = playlists.firstOrNull { it.id == id }
    var edit by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var delete by remember { mutableStateOf(false) }

    if (playlist == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }

    CollectionScreen(
        title = playlist.name,
        subtitle = plural(playlist.songs.size, "música", "músicas"),
        songs = playlist.songs,
        coverSong = playlist.songs.firstOrNull(),
        heroIcon = null,
        ctx = ctx,
        onBack = onBack,
        topActions = {
            IconButton(onClick = { edit = !edit }) {
                Icon(
                    if (edit) Icons.Rounded.Check else Icons.Rounded.SwapVert,
                    contentDescription = if (edit) "Concluir" else "Reordenar"
                )
            }
            IconButton(onClick = { rename = true }) {
                Icon(Icons.Rounded.Edit, contentDescription = "Renomear")
            }
            IconButton(onClick = { delete = true }) {
                Icon(Icons.Rounded.Delete, contentDescription = "Excluir playlist")
            }
        },
        editMode = edit,
        onMove = { from, to -> vm.moveInPlaylist(playlist.id, from, to) },
        onRemove = { song -> vm.removeFromPlaylist(playlist.id, song) }
    )

    if (rename) {
        NameDialog(
            title = "Renomear playlist",
            initial = playlist.name,
            confirm = "Salvar",
            onConfirm = { name ->
                vm.renamePlaylist(playlist.id, name)
                rename = false
            },
            onDismiss = { rename = false }
        )
    }
    if (delete) {
        AlertDialog(
            onDismissRequest = { delete = false },
            containerColor = JntColors.Card,
            titleContentColor = Color.White,
            textContentColor = JntColors.TextSecondary,
            title = { Text("Excluir playlist?") },
            text = { Text("\"${playlist.name}\" será removida. As músicas continuam no aparelho.") },
            confirmButton = {
                TextButton(onClick = {
                    delete = false
                    vm.deletePlaylist(playlist.id)
                    onBack()
                }) { Text("Excluir", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { delete = false }) { Text("Cancelar", color = JntColors.TextSecondary) }
            }
        )
    }
}

@Composable
fun CollectionScreen(
    title: String,
    subtitle: String,
    songs: List<Song>,
    coverSong: Song?,
    heroIcon: ImageVector?,
    ctx: ListCtx,
    onBack: () -> Unit,
    topActions: @Composable RowScope.() -> Unit = {},
    editMode: Boolean = false,
    onMove: (Int, Int) -> Unit = { _, _ -> },
    onRemove: ((Song) -> Unit)? = null
) {
    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Voltar")
                }
                Spacer(Modifier.weight(1f))
                topActions(this)
            }
        }
        item {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (heroIcon != null) {
                    Box(
                        Modifier
                            .size(220.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFF3A3A3A), Color(0xFF151515)))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(heroIcon, contentDescription = null, tint = Color.White, modifier = Modifier.size(80.dp))
                    }
                } else {
                    CoverImage(coverSong, Modifier.size(220.dp), corner = 24.dp, px = 640)
                }
                Spacer(Modifier.height(20.dp))
                Text(
                    title,
                    color = Color.White,
                    style = MaterialTheme.typography.headlineMedium,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(4.dp))
                Text(subtitle, color = JntColors.TextSecondary, fontSize = 14.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(20.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    PillButton("Reproduzir", Icons.Rounded.PlayArrow, filled = true, onClick = {
                        if (songs.isNotEmpty()) ctx.vm.play(songs, 0)
                    })
                    PillButton("Aleatório", Icons.Rounded.Shuffle, filled = false, onClick = {
                        ctx.vm.playShuffled(songs)
                    })
                }
                Spacer(Modifier.height(16.dp))
            }
        }

        if (songs.isEmpty()) {
            item {
                EmptyState(
                    Icons.Rounded.MusicNote,
                    "Nada por aqui ainda",
                    "Adicione músicas pelo menu de cada faixa."
                )
            }
        } else if (editMode) {
            itemsIndexed(songs, key = { _, s -> s.id }) { index, song ->
                SongRow(
                    song = song,
                    current = song.id == ctx.currentId,
                    favorite = song.id in ctx.favs,
                    onClick = {},
                    onToggleFavorite = {},
                    onAddToPlaylist = {},
                    modifier = Modifier.padding(horizontal = 16.dp).animateItem(),
                    trailing = {
                        IconButton(onClick = { onMove(index, index - 1) }, enabled = index > 0) {
                            Icon(Icons.Rounded.ArrowUpward, contentDescription = "Subir")
                        }
                        IconButton(onClick = { onMove(index, index + 1) }, enabled = index < songs.lastIndex) {
                            Icon(Icons.Rounded.ArrowDownward, contentDescription = "Descer")
                        }
                        if (onRemove != null) {
                            IconButton(onClick = { onRemove(song) }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Remover da playlist")
                            }
                        }
                    }
                )
            }
        } else {
            songItems(songs, ctx, modifier = Modifier.padding(horizontal = 16.dp))
        }
    }
}
