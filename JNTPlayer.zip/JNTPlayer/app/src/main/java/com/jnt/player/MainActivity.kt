package com.jnt.player

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.jnt.player.ui.JntApp
import com.jnt.player.ui.MainViewModel
import com.jnt.player.ui.theme.JntColors
import com.jnt.player.ui.theme.JntTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        setContent {
            JntTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = JntColors.Bg,
                    contentColor = androidx.compose.ui.graphics.Color.White
                ) {
                    JntApp(vm)
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        vm.refreshPermission()
    }
}
