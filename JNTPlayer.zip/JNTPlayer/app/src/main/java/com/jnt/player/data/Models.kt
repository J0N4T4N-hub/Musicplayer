package com.jnt.player.data

import android.content.ContentUris
import android.net.Uri
import android.provider.MediaStore

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val dateAdded: Long,
    val track: Int
) {
    val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
}

data class Album(val id: Long, val name: String, val artist: String, val songs: List<Song>)

data class Artist(val name: String, val songs: List<Song>) {
    val albumCount: Int get() = songs.map { it.albumId }.distinct().size
}

data class PlaylistUi(val id: Long, val name: String, val songs: List<Song>)

data class SearchResults(
    val songs: List<Song> = emptyList(),
    val albums: List<Album> = emptyList(),
    val artists: List<Artist> = emptyList()
) {
    val isEmpty: Boolean get() = songs.isEmpty() && albums.isEmpty() && artists.isEmpty()
}

enum class SortOrder(val label: String) {
    NAME("Nome"),
    ARTIST("Artista"),
    ALBUM("Álbum"),
    RECENT("Mais recentes"),
    MOST_PLAYED("Mais tocadas")
}
